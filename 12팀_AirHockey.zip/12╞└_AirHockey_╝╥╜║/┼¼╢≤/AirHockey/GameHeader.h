#pragma once
#include "framework.h"
#include "AirHockey.h"
#include "Player.h"
#include "Ball.h"
#include <stdio.h>



#define MAX_LOADSTRING 100

#define SERVERIP "127.0.0.1"
//#define SERVERIP "192.168.100.255"
#define SERVERPORT  9000
#define BUFSIZE 512

